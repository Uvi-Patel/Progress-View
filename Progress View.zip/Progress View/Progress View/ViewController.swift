//
//  ViewController.swift
//  Progress View
//
//  Created by MAC on 25/06/21.
//  Copyright © 2021 com.genesis.demo. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var progressView: UIProgressView!
 
    override func viewDidLoad() {
        super.viewDidLoad()
        
        progressView.setProgress(0.5, animated: true)
        
        let progressV = UIProgressView(progressViewStyle: .bar)
        progressV.frame = CGRect(x: 50, y: 200, width: self.view.frame.size.width-100, height: 100)
        let transform = CGAffineTransform(scaleX: 1.2, y: 2.2)
        progressV.transform = transform
        progressView.transform = transform
        UIView.animate(withDuration: 10.0)
               {
                    progressV.setProgress(1, animated: true)
               }
      //  progressV.progressImage = UIImage(named: "ff")
        progressV.backgroundColor = UIColor.green
        progressV.progressTintColor = UIColor.black
       // progressV.setProgress(1, animated: true)
        view.addSubview(progressV)
        // Do any additional setup after loading the view.
    }


}

